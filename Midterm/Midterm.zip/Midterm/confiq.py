class Config:
    def __init__(self):
        self.DEBUG = True
        self.SQLALCHEMY_DATABASE_URI = "postgresql://admin:Rupp2357.!@localhost:5432/AdminDB"
